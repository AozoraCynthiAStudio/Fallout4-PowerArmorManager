Power Armor Storage 2.2.7

Requirements
1. Fallout 4
2. Fallout 4 Script Extender (F4SE) - Download the version that matches your Fallout 4 game version
   https://www.nexusmods.com/fallout4/mods/42147
3. Address Library for F4SE Plugins - Download the version that matches your Fallout 4 game version
   https://www.nexusmods.com/fallout4/mods/47327
4. Mod Configuration Menu (MCM) - Download the version that matches your Fallout 4 game version
   https://www.nexusmods.com/fallout4/mods/21497
5. Prisma UI Framework 2.0.2 or a compatible later 2.x version
   https://www.nexusmods.com/fallout4/mods/105454
6. Garden of Eden Papyrus Script Extender (GOE)
   https://www.nexusmods.com/fallout4/mods/74160

Important
- This package is the GOE version. Garden of Eden Papyrus Script Extender must be installed and enabled.
- F4SE, Address Library, MCM, and Prisma UI must match your Fallout 4 game version.
- This is the full ESP release. The plugin is PowerArmorMgr.esp and uses one ESP plugin slot.
- Install only one language package. Do not enable the Chinese and English packages at the same time.

Installation
1. Install and enable all required dependencies listed above.
2. Install the complete contents of this folder with Mod Organizer 2, Vortex, or another mod manager.
3. After installation, the mod root should directly contain:
   F4SE
   MCM
   PrismaUI_F4
   Scripts
   Sound
   PowerArmorMgr.esp
4. Enable this mod and make sure PowerArmorMgr.esp is enabled in your mod manager.
5. Start Fallout 4 through F4SE. Do not start the game through the normal Fallout4.exe launcher.
6. In game, open the Power Armor Storage page in MCM and check the main UI hotkey and Primary Power Armor hotkey.

Updating and language switching
- Disable or uninstall the previous version before upgrading. Do not mix old scripts, UI files, or folders with this release.
- Do not place an old version inside the new version folder, and do not enable more than one PowerArmorMgr.esp.
- When changing languages, keep only the Chinese package or the English package installed and enabled.

Notes
- Keyboard and gamepad are supported; mouse input is intentionally disabled in this release.
- The mod provides 50 Power Armor slots. Slot 01 is reserved for Primary Power Armor.
- Regular slots use GOE to identify the Power Armor under the crosshair before storing or deploying it.
- Primary Power Armor can be deployed or recalled with the separate MCM-configured hotkey without GOE target detection.
- Storing a new frame in slot 01 through the storage UI creates a new Primary Power Armor binding.
- Moving quest-specific or quest-related Power Armor may affect quest progression. Consider the risk before using this mod on such frames.
- This mod does not guarantee quest, progression, or save integrity after abnormal player actions.

Uninstallation notes
- Before uninstalling or changing versions, handle any Power Armor currently stored in the warehouse in game and make a normal save.
- Do not enable multiple versions of Power Armor Storage in the same save.
