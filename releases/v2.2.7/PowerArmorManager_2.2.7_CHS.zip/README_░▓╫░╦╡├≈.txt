动力甲仓库 2.2.7

必需前置
1. Fallout 4 本体
2. Fallout 4 Script Extender (F4SE) 请根据游戏本体版本下载对应版本
   https://www.nexusmods.com/fallout4/mods/42147
3. Address Library for F4SE Plugins 请根据游戏本体版本下载对应版本
   https://www.nexusmods.com/fallout4/mods/47327
4. Mod Configuration Menu (MCM) 请根据游戏本体版本下载对应版本
   https://www.nexusmods.com/fallout4/mods/21497
5. Prisma UI Framework 2.0.2 或兼容的后续 2.x 版本
   https://www.nexusmods.com/fallout4/mods/105454
6. Garden of Eden Papyrus Script Extender（简称 GOE）
   https://www.nexusmods.com/fallout4/mods/74160

重要
- 本包是 GOE 版本，必须安装并启用 Garden of Eden Papyrus Script Extender。
- F4SE、Address Library、MCM 和 Prisma UI 都必须与当前 Fallout 4 本体版本兼容。
- 本包是正式 ESP 版本，插件文件为 PowerArmorMgr.esp，会占用一个 ESP 插件位。
- 中文版和英文版只能选择一个安装，不要同时启用两个语言包。

安装
1. 先安装并启用以上全部必需前置。
2. 使用 Mod Organizer 2、Vortex 等模组管理器安装本文件夹的完整内容。
3. 安装完成后，模组根目录应能直接看到以下内容：
   F4SE
   MCM
   PrismaUI_F4
   Scripts
   Sound
   PowerArmorMgr.esp
4. 在模组管理器中启用本模组，并确认 PowerArmorMgr.esp 已启用。
5. 使用 F4SE 启动 Fallout 4，不要使用普通 Fallout4.exe 启动。
6. 进入游戏后，在 MCM 中打开“动力甲仓库”页面，检查主界面热键和主动力甲热键。

升级与切换语言
- 升级前请先在模组管理器中卸载或禁用旧版，避免旧版脚本、界面和文件与新版叠加。
- 不要把旧版文件夹套在新版文件夹里面，也不要让两个 PowerArmorMgr.esp 同时启用。
- 更换语言时，只保留中文包或英文包中的一个。

说明
- 支持键盘与手柄操作，当前版本不启用鼠标操作。
- 提供 50 个动力甲槽位；第 01 槽位为主动力甲专用槽位。
- 普通槽位通过 GOE 识别准星指向的动力甲，再执行保存或部署。
- 主动力甲可以通过 MCM 设置的独立热键快速部署或召回，不需要 GOE 准星识别。
- 通过仓库界面将新的动力甲存入第 01 槽位时，会重新绑定主动力甲。
- 任务专用或任务流程中的动力甲可能受到移动影响。使用本模组移动这类动力甲前，请自行确认任务风险。
- 本模组不为玩家的异常操作、任务流程变化或存档问题提供保证。

卸载注意
- 卸载或切换版本前，建议先在游戏内处理已经存入仓库的动力甲，并完成一次正常存档。
- 同一个存档不要同时启用多个版本的动力甲仓库。
